package com.example.learnenglishwordssecondtry;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ChooseSetToView extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_set_to_view);

        Button set1Button;
        Button set2Button;
        Button set3Button;

        set1Button = findViewById(R.id.chosenSet1Button);
        set2Button = findViewById(R.id.chosenSet2Button);
        set3Button =  findViewById(R.id.chosenSet3Button);

        set1Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = ViewSetOfWordsActivity.newIntent(
                        ChooseSetToView.this, 1);
                startActivity(intent);
            }
        });

        set2Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = ViewSetOfWordsActivity.newIntent(
                        ChooseSetToView.this, 2);
                startActivity(intent);
            }
        });

        set3Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = ViewSetOfWordsActivity.newIntent(
                        ChooseSetToView.this, 3);
                startActivity(intent);
            }
        });

    }
}
