package com.example.learnenglishwordssecondtry;

import java.lang.Comparable;

public class Word implements Comparable<Word> {

    public String wordEng;
    public String wordRus;

    public Word (String eng, String rus) {
        wordEng = eng;
        wordRus = rus;
    }

    public Word (Word w) {
        this(w.wordEng, w.wordRus);
    }

    public boolean isCorrect(boolean rusEngWay, String answer) {
        if ((rusEngWay && answer.toLowerCase().equals(wordEng.toLowerCase()))
                    || (!rusEngWay && answer.toLowerCase().equals(wordRus.toLowerCase())))  {
            return true;
        }
        return false;
    }

    public String getAnswer(boolean rusEngWay) {
        if (rusEngWay) {
            return wordEng;
        }
        return wordRus;
    }


    public int	compareTo(Word w) {

        return this.wordEng.compareToIgnoreCase(w.wordEng);
    }


}
