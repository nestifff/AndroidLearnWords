package com.example.learnenglishwordssecondtry;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

// all with recyclerView change
public class ViewSetOfWordsActivity extends AppCompatActivity {

    private static final String SETNumber = "chosenSetNumber";
    private int setNumber;
    private RecyclerView recyclerView;

    public static Intent newIntent (Context packageContext, int setNumber) {
        Intent intent = new Intent(packageContext, ViewSetOfWordsActivity.class);
        intent.putExtra(SETNumber, setNumber);

        return intent;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_set_of_words);

        setNumber = getIntent().getIntExtra(SETNumber, -1);

        Toast.makeText(ViewSetOfWordsActivity.this, "Number of set is " + setNumber, Toast.LENGTH_SHORT).show();

        //recyclerView = findViewById(R.id.view_set_recycleView);
        //recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
}
