package com.example.learnenglishwordssecondtry;

import java.util.ArrayList;
import java.util.List;

//singlet class, has only one object

public class WordsSet {

    private static WordsSet wordsSetObj;

    private List<List<Word>> sets;

    public static WordsSet get() {
        wordsSetObj = new WordsSet();
        return wordsSetObj;
    }

    private WordsSet() {

        sets = new ArrayList<>();
        for (int i = 0; i < 3; ++i) {
            ArrayList<Word> setTemp = new ArrayList<>();
            sets.add(setTemp);
        }
        addToList();
    }

    public List<List<Word>> getSets() {
        return sets;
    }

    public List<Word> getOneSet(int n) {
        if (n <= sets.size()) {
            return sets.get(n - 1);
        }
        return sets.get(0);
    }

    private void addToList() {

        for (int i = 0; i <= 2; ++i) {

            switch (i) {

                case (0):

                    sets.get(i).add(new Word("disparity", "неравенство"));
                    sets.get(i).add(new Word("sophisticated", "сложный"));
                    sets.get(i).add(new Word("implementation", "реализация"));
                    sets.get(i).add(new Word("eventually", "в конце концов"));
                    sets.get(i).add(new Word("repeatedly", "неоднократно"));
                    sets.get(i).add(new Word("nascent", "возникающий"));
                    sets.get(i).add(new Word("comprised", "состоит"));
                    sets.get(i).add(new Word("shrink", "сокращаться"));
                    sets.get(i).add(new Word("enormous", "огромный"));
                    sets.get(i).add(new Word("preserve", "сохранять"));
                    sets.get(i).add(new Word("traversing", "перемещение"));
                    sets.get(i).add(new Word("incrementally", "пошагово"));
                    sets.get(i).add(new Word("ambit", "в пределах"));
                    sets.get(i).add(new Word("dashed line", "пунктирная линия"));

                    sets.get(i).add(new Word("further", "кроме того"));
                    sets.get(i).add(new Word("inference", "вывод"));
                    sets.get(i).add(new Word("resurgence", "восстановление"));
                    sets.get(i).add(new Word("controversial", "спорный"));
                    sets.get(i).add(new Word("grappling", "борьба"));

                    sets.get(i).add(new Word("internal", "внутренний"));
                    sets.get(i).add(new Word("validation", "проверка"));
                    sets.get(i).add(new Word("symmetric", "симметричный"));
                    sets.get(i).add(new Word("inequality", "неравенство"));

                    sets.get(i).add(new Word("underlie", "лежать в основе"));
                    sets.get(i).add(new Word("comprehensible", "понятный"));
                    sets.get(i).add(new Word("ultimately", "в конечном счёте"));
                    sets.get(i).add(new Word("invariably", "неизменно"));
                    sets.get(i).add(new Word("denote", "обозначать"));
                    sets.get(i).add(new Word("judgment", "мнение"));
                    sets.get(i).add(new Word("emphasis", "акцент"));
                    sets.get(i).add(new Word("loan", "заимствование"));
                    sets.get(i).add(new Word("detecting", "обнаружение"));
                    sets.get(i).add(new Word("hazard", "опасность"));
                    sets.get(i).add(new Word("preventative", "профилактический"));
                    sets.get(i).add(new Word("equate", "приравнивать"));
                    sets.get(i).add(new Word("discard", "отбрасывать"));
                    sets.get(i).add(new Word("regarded", "рассматривать"));

                    sets.get(i).add(new Word("enumerate", "перечислять"));
                    sets.get(i).add(new Word("finite", "ограниченный"));
                    sets.get(i).add(new Word("restrict", "ограничивать"));
                    sets.get(i).add(new Word("patently", "очевидно"));
                    sets.get(i).add(new Word("feasible", "выполнимый"));
                    sets.get(i).add(new Word("acceptable", "приемлемый"));
                    sets.get(i).add(new Word("eliminate", "ликвидировать"));
                    sets.get(i).add(new Word("sufficiently", "достаточно"));
                    sets.get(i).add(new Word("to capture", "охватывать"));
                    sets.get(i).add(new Word("assign", "назначать"));
                    sets.get(i).add(new Word("specified", "указанный"));
                    sets.get(i).add(new Word("strike out", "вычеркивать"));
                    sets.get(i).add(new Word("impose", "налагать"));
                    sets.get(i).add(new Word("constraint", "ограничение"));
                    sets.get(i).add(new Word("capable", "способный"));
                    sets.get(i).add(new Word("statement", "утверждение"));
                    sets.get(i).add(new Word("precision", "точность"));
                    sets.get(i).add(new Word("in either case", "В любом случае"));
                    sets.get(i).add(new Word("error rate", "частота ошибок"));

                    break;

                case (1):

                    sets.get(i).add(new Word("pertain", "относиться"));
                    sets.get(i).add(new Word("origin", "происхождение"));
                    sets.get(i).add(new Word("mimic", "подражать"));
                    sets.get(i).add(new Word("diminish", "уменьшить"));
                    sets.get(i).add(new Word("perform", "выполнять"));
                    sets.get(i).add(new Word("approximation", "приближение"));
                    sets.get(i).add(new Word("extent", "степень"));
                    sets.get(i).add(new Word("resolution", "разрешение"));
                    sets.get(i).add(new Word("correspond", "соответствовать"));
                    sets.get(i).add(new Word("figure out", "выяснять"));
                    sets.get(i).add(new Word("intermediate", "промежуточный"));
                    sets.get(i).add(new Word("propagation", "распространение"));
                    sets.get(i).add(new Word("negation", "отрицание"));
                    sets.get(i).add(new Word("feasible", "выполнимый"));
                    sets.get(i).add(new Word("summation", "суммирование"));
                    sets.get(i).add(new Word("fraudulent", "обманный"));
                    sets.get(i).add(new Word("absence", "отсуствие"));
                    sets.get(i).add(new Word("convey", "передавать"));
                    sets.get(i).add(new Word("threshold", "порог"));
                    sets.get(i).add(new Word("satisfy", "удовлетворять"));
                    sets.get(i).add(new Word("defer", "отложить"));
                    sets.get(i).add(new Word("curve", "кривая"));
                    sets.get(i).add(new Word("concise", "краткий"));
                    sets.get(i).add(new Word("installment", "взнос"));
                    sets.get(i).add(new Word("opaque", "непрозрачный"));
                    sets.get(i).add(new Word("lump", "свалить"));
                    sets.get(i).add(new Word("preconception", "предвзятость"));
                    sets.get(i).add(new Word("variance", "дисперсия"));
                    sets.get(i).add(new Word("depth", "глубина"));
                    sets.get(i).add(new Word("penalise", "наказывать"));

                    break;

                case (2):

                    sets.get(i).add(new Word("prone", "склонный"));
                    sets.get(i).add(new Word("objective", "задача"));
                    sets.get(i).add(new Word("trade off", "компромисс"));
                    sets.get(i).add(new Word("invertibility", "необратимость"));
                    sets.get(i).add(new Word("omitted", "пропущено"));
                    sets.get(i).add(new Word("tricky", "запутанный"));
                    sets.get(i).add(new Word("subtle", "тонкий"));
                    sets.get(i).add(new Word("take on faith", "принять на веру"));
                    sets.get(i).add(new Word("slope", "наклон"));
                    sets.get(i).add(new Word("estimate", "оценка"));
                    sets.get(i).add(new Word("accuracy", "точность"));
                    sets.get(i).add(new Word("reiterate", "подтверждать"));
                    sets.get(i).add(new Word("clarity", "ясность"));
                    sets.get(i).add(new Word("indeed", "на самом деле"));
                    sets.get(i).add(new Word("evaluation", "оценка"));
                    sets.get(i).add(new Word("time-consuming", "трудоемкий"));


                    break;

            }
        }

    }

}
