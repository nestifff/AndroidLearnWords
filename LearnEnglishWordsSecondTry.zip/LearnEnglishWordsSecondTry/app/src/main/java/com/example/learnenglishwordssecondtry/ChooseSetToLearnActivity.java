package com.example.learnenglishwordssecondtry;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ChooseSetToLearnActivity extends AppCompatActivity {

    private TextView wayToLearnText;
    boolean rusEngWay = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_set_to_learn);

        Button set1Button;
        Button set2Button;
        Button set3Button;

        Button changeWayOfLearnButton;

        set1Button = findViewById(R.id.chosenSet1Button);
        set2Button = findViewById(R.id.chosenSet2Button);
        set3Button =  findViewById(R.id.chosenSet3Button);

        changeWayOfLearnButton = findViewById(R.id.button_changeWayToLearn);
        wayToLearnText =  findViewById(R.id.text_wayToLearn);

        changeWayOfLearnButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String text;
                if(rusEngWay) {
                    rusEngWay = false;
                    text  = getString(R.string.text_engRusWayToLearn);
                } else {
                    rusEngWay = true;
                    text  = getString(R.string.text_rusEngWayToLearn);
                }
                wayToLearnText.setText(text);
            }
        });

        set1Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = LearnSetOfWordsActivity.newIntent(
                        ChooseSetToLearnActivity.this, rusEngWay, true, false, false);
                startActivity(intent);
            }
        });

        set2Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = LearnSetOfWordsActivity.newIntent(
                        ChooseSetToLearnActivity.this, rusEngWay,false, true, false);
                startActivity(intent);
            }
        });

        set3Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = LearnSetOfWordsActivity.newIntent(
                        ChooseSetToLearnActivity.this, rusEngWay,false, false, true);
                startActivity(intent);
            }
        });
    }
}
