package com.example.learnenglishwordssecondtry;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

//chose what to do, first window

public class MainActivity extends AppCompatActivity {

    private Button learnWordsButton;
    private Button viewAllMyWordsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        learnWordsButton = findViewById(R.id.chosenLearnWordsButton);
        viewAllMyWordsButton = findViewById(R.id.chosenViewAllMyWordsButton);

        learnWordsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ChooseSetToLearnActivity.class);
                startActivity(intent);
            }
        });

        viewAllMyWordsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ChooseSetToView.class);
                startActivity(intent);
                //Toast.makeText(MainActivity.this, "This option isn't available", Toast.LENGTH_SHORT).show();
            }
        });

    }
}

