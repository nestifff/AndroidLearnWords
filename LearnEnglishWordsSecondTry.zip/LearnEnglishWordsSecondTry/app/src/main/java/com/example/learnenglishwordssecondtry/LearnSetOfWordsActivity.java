package com.example.learnenglishwordssecondtry;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Random;

public class LearnSetOfWordsActivity extends AppCompatActivity {

    public String answer;
    public List<Word> words;
    private WordsSet wordsSetObj;

    private int numOfSet;

    private static final String SET1 = "chosen1Set";
    private static final String SET2 = "chosen2Set";
    private static final String SET3 = "chosen3Set";
    private static final String WAY = "wayToLearnIsRusEng";

    private EditText answerEditText;
    private Button nextWordButton;
    private TextView answerStatusText;
    private TextView wordToRecallText;
    private TextView wordsRemainText;

    public boolean rusEngWay;
    private Word lastWord;

    private HashMap<Word, Integer> wordsQAttempts;
    private TextView resText;


    public static Intent newIntent (Context packageContext, boolean rusEngWayTemp, boolean set1, boolean set2, boolean set3) {
        Intent intent = new Intent(packageContext, LearnSetOfWordsActivity.class);
        intent.putExtra(WAY, rusEngWayTemp);
        intent.putExtra(SET1, set1);
        intent.putExtra(SET2, set2);
        intent.putExtra(SET3, set3);

        return intent;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_learn_set_of_words);

        TextView wayToLearnText;
        Button goHomeButton;

        wayToLearnText = findViewById(R.id.text_wayToLearn);
        goHomeButton = findViewById(R.id.button_goHome);

        answerStatusText = findViewById(R.id.text_answerStatus);
        nextWordButton = findViewById(R.id.button_askNextWord);
        answerEditText = findViewById(R.id.editText_answer);
        wordToRecallText = findViewById(R.id.text_wordToRecall);
        wordsRemainText = findViewById(R.id.text_wordsRemain);

        resText = findViewById(R.id.text_resultsTemporary);

        if (getIntent().getBooleanExtra(SET1, false)) {
            numOfSet = 1;
        } else if(getIntent().getBooleanExtra(SET2, false)) {
            numOfSet = 2;
        } else if(getIntent().getBooleanExtra(SET3, false)) {
            numOfSet = 3;
        }

        rusEngWay = getIntent().getBooleanExtra(WAY, false);
        if(rusEngWay) {
            wayToLearnText.setText(getString(R.string.text_rusEngWayToLearn));
            answerEditText.setHint(getString(R.string.textHint_enterAnswerRusEng));
        } else {
            wayToLearnText.setText(getString(R.string.text_engRusWayToLearn));
            answerEditText.setHint(getString(R.string.textHint_enterAnswerEngRus));

        }

        wordsQAttempts = new HashMap<>();

        createSet();

        wordsRemainText.setText(words.size() + " words");

        askWord();

        nextWordButton.setEnabled(false);

        answerEditText.setOnKeyListener(new View.OnKeyListener() {

            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_DOWN &&
                        (keyCode == KeyEvent.KEYCODE_ENTER)) {

                    answer = answerEditText.getText().toString();
                    nextWordButton.setEnabled(true);

                    determineAndShowStatusOfAnswer();
                    answerEditText.setEnabled(false);
                    return true;
                }

                return false;
            }
        });

        goHomeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LearnSetOfWordsActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        nextWordButton.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("NewApi")
            @Override
            public void onClick(View v) {
                nextWordButton.setEnabled(false);
                answerEditText.setEnabled(true);
                answerStatusText.setText("");
                answerEditText.setText("");

                answerEditText.requestFocus();
                @SuppressLint({"NewApi", "LocalSuppress"}) InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(answerEditText, InputMethodManager.SHOW_IMPLICIT);

                if (words.size() != 0) {
                    askWord();
                } else {
                    goToResults();
                    Toast.makeText(LearnSetOfWordsActivity.this, "You are win!", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private void determineAndShowStatusOfAnswer() {


        int n = wordsQAttempts.get(lastWord) + 1;
        wordsQAttempts.remove(lastWord);
        wordsQAttempts.put(lastWord, n);


        if (lastWord.isCorrect(rusEngWay, answer)) {

            words.remove(lastWord);
            answerStatusText.setText("You are right");
            wordsRemainText.setText(words.size() + " words");

        } else {
            answerStatusText.setText("You are wrong, right answer is \n" + lastWord.getAnswer(rusEngWay));
        }
    }

    private void createSet() {
        wordsSetObj = WordsSet.get();
        words = wordsSetObj.getOneSet(numOfSet);

        for (Word w : words) {
            wordsQAttempts.put(w, 0);
        }

    }

    private void askWord() {

        Random random = new Random();
        int n;

        if (words.size() != 1) {
            do {
                n = random.nextInt(words.size());
            } while (words.get(n) == lastWord);
        } else {
            n = 0;
        }

        lastWord = words.get(n);

        if (rusEngWay) {
            wordToRecallText.setText(lastWord.wordRus);
        } else {
            wordToRecallText.setText(lastWord.wordEng);
        }

    }


    public LinkedHashMap<Word, Integer> sortHashMapByValues(
            HashMap<Word, Integer> passedMap) {

        List<Word> mapKeys = new ArrayList<>(passedMap.keySet());
        List<Integer> mapValues = new ArrayList<>(passedMap.values());
        Collections.sort(mapValues);
        Collections.sort(mapKeys);

        LinkedHashMap<Word, Integer> sortedMap =
                new LinkedHashMap<>();

        Iterator<Integer> valueIt = mapValues.iterator();
        while (valueIt.hasNext()) {
            Integer val = valueIt.next();
            Iterator<Word> keyIt = mapKeys.iterator();

            while (keyIt.hasNext()) {
                Word key = keyIt.next();
                Integer comp1 = passedMap.get(key);
                Integer comp2 = val;

                if (comp1.equals(comp2)) {
                    keyIt.remove();
                    sortedMap.put(key, val);
                    break;
                }
            }
        }
        return sortedMap;
    }

    void goToResults() {

        answerEditText.setEnabled(false);

        LinkedHashMap<Word, Integer> sortedResults = sortHashMapByValues(wordsQAttempts);
        List<Word> listWords = new ArrayList<>(sortedResults.keySet());
        List<Integer> listAttempts = new ArrayList<>(sortedResults.values());

        String text = new String();
        int onTheFirstTry = 0;

        for (int i = 0; i < listAttempts.size(); ++i) {
            if (listAttempts.get(i) != 1) {
                break;
            }
            ++onTheFirstTry;
        }

        text += "On the first try " + onTheFirstTry + " words. \n" + "\n";

        for (int i = 1; i <= 5; ++i) {
            if ((listAttempts.get(listWords.size() - i) != 1) && i == 1) {
                text += "The most difficult words: \n";
            }
            if (listAttempts.get(listWords.size() - i) == 1) {
                break;
            }
            text += listWords.get(listWords.size() - i).wordEng + " - " +
                    listWords.get(listWords.size() - i).wordRus + ": " +
                    listAttempts.get(listWords.size() - i) + "\n";
        }

        int numOfAttempts = 0;
        for (Integer n : listAttempts) {
            numOfAttempts += n;
        }

        text += "\n";

        double av = (double)numOfAttempts / (double)listWords.size();
        text += "Average number of attempts for one word is " + av + "\n";

        resText.setText(text);
    }


}
